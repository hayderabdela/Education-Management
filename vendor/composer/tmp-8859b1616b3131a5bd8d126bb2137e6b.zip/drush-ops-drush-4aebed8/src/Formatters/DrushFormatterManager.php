<?php

declare(strict_types=1);

namespace Drush\Formatters;

use Consolidation\OutputFormatters\FormatterManager;

/**
 * Our own output formatter
 */
class DrushFormatterManager extends FormatterManager
{
}
