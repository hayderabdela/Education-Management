<?php

namespace Consolidation\OutputFormatters\StructuredData;

use Consolidation\OutputFormatters\StructuredData\Xml\DomDataInterface;

class HelpDocument implements DomDataInterface
{
    /**
     * Convert data into a \DomDocument.
     *
     * @return \DomDocument
     */
    public function getDomData()
    {
    }
}
