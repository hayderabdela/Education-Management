<?php

declare(strict_types=1);

namespace DrupalCodeGenerator\Asset;

// @todo Is it still needed?
\class_alias(AssetCollection::class, '\DrupalCodeGenerator\Asset\Assets');
