<?php

namespace Robo\Config;

/**
 * @deprecated Use robo.yml instead
 *
 * robo.yml:
 *
 * options:
 *   simulated: false
 *   progress-delay: 2
 *
 * etc.
 */
interface GlobalOptionDefaultValuesInterface extends \Consolidation\Config\GlobalOptionDefaultValuesInterface
{
}
