<?php

namespace Robo\Contract;

interface ConfigAwareInterface extends \Consolidation\Config\ConfigAwareInterface
{
}
